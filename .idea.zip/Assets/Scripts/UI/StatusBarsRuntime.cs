using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Creates a simple 2D status-bar HUD (Health/Hunger/Thirst/Energy/Warmth/Stress)
/// at runtime, matching the look of the reference image.
/// 
/// How to drive it from gameplay:
///   StatusBarsRuntime.Instance.SetValue("Health", 0.75f);
/// Values are normalized 0..1.
/// </summary>
public class StatusBarsRuntime : MonoBehaviour
{
    public static StatusBarsRuntime Instance { get; private set; }

    [Header("Auto-create")]
    [Tooltip("If enabled, the HUD only shows in the 3D_island_demo scene.")]
    public bool onlyIn3DIslandDemo = true;

    [Header("Layout")]
    public Vector2 panelOffset = new Vector2(20f, 20f);
    public Vector2 rowSize = new Vector2(360f, 26f);
    public float rowGap = 8f;
    public float labelWidth = 92f;
    public float padding = 2f;

    private readonly Dictionary<string, Image> _fills = new Dictionary<string, Image>(StringComparer.OrdinalIgnoreCase);
    private Canvas _canvas;
    private RectTransform _panel;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Bootstrap()
    {
        // Avoid duplicates.
        if (FindAnyObjectByType<StatusBarsRuntime>() != null) return;

        var go = new GameObject("StatusBarsRuntime");
        DontDestroyOnLoad(go);
        go.AddComponent<StatusBarsRuntime>();
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        SceneManager.sceneLoaded += OnSceneLoaded;
        TryBuildUI();
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        ApplySceneVisibility(scene.name);
        // If UI got destroyed by domain reload / scene changes, rebuild.
        if (_canvas == null) TryBuildUI();
        ApplySceneVisibility(scene.name);
    }

    private void ApplySceneVisibility(string sceneName)
    {
        if (_canvas == null) return;

        bool shouldShow = !onlyIn3DIslandDemo || string.Equals(sceneName, "3D_island_demo", StringComparison.OrdinalIgnoreCase);
        _canvas.gameObject.SetActive(shouldShow);
    }

    private void TryBuildUI()
    {
        // Build a dedicated overlay canvas.
        var canvasGO = new GameObject("StatusBarsCanvas");
        DontDestroyOnLoad(canvasGO);

        _canvas = canvasGO.AddComponent<Canvas>();
        _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        _canvas.sortingOrder = 2000;

        var scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;

        canvasGO.AddComponent<GraphicRaycaster>();

        EnsureEventSystemExists();

        // Panel container (top-left).
        var panelGO = new GameObject("Panel", typeof(RectTransform));
        panelGO.transform.SetParent(canvasGO.transform, false);
        _panel = panelGO.GetComponent<RectTransform>();
        _panel.anchorMin = new Vector2(0f, 1f);
        _panel.anchorMax = new Vector2(0f, 1f);
        _panel.pivot = new Vector2(0f, 1f);
        _panel.anchoredPosition = new Vector2(panelOffset.x, -panelOffset.y);

        // Create rows.
        var rows = new (string name, Color color)[]
        {
            ("Health",  new Color(0.86f, 0.28f, 0.28f, 1f)),
            ("Hunger",  new Color(0.93f, 0.66f, 0.22f, 1f)),
            ("Thirst",  new Color(0.39f, 0.64f, 0.93f, 1f)),
            ("Energy / sleep", new Color(0.47f, 0.75f, 0.39f, 1f)),
            ("Warmth", new Color(0.93f, 0.66f, 0.22f, 1f)),
            ("Stress", new Color(0.63f, 0.46f, 0.80f, 1f))
        };

        float totalHeight = rows.Length * rowSize.y + (rows.Length - 1) * rowGap;
        _panel.sizeDelta = new Vector2(rowSize.x, totalHeight);

        for (int i = 0; i < rows.Length; i++)
        {
            float y = -(i * (rowSize.y + rowGap));
            CreateRow(_panel, rows[i].name, rows[i].color, y);
        }

        // Set some pleasant defaults for demo.
        SetValue("Health", 0.80f);
        SetValue("Hunger", 0.55f);
        SetValue("Thirst", 0.70f);
        SetValue("Energy / sleep", 0.45f);
        SetValue("Warmth", 0.60f);
        SetValue("Stress", 0.35f);

        ApplySceneVisibility(SceneManager.GetActiveScene().name);
    }

    private void EnsureEventSystemExists()
    {
        // Needed for UI input; harmless if you don't use input.
        if (FindAnyObjectByType<UnityEngine.EventSystems.EventSystem>() != null) return;

        var es = new GameObject("EventSystem");
        DontDestroyOnLoad(es);
        es.AddComponent<UnityEngine.EventSystems.EventSystem>();
        es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
    }

    private void CreateRow(RectTransform parent, string label, Color accent, float y)
    {
        var rowGO = new GameObject(label + "_Row", typeof(RectTransform));
        rowGO.transform.SetParent(parent, false);
        var rowRT = rowGO.GetComponent<RectTransform>();
        rowRT.anchorMin = new Vector2(0f, 1f);
        rowRT.anchorMax = new Vector2(0f, 1f);
        rowRT.pivot = new Vector2(0f, 1f);
        rowRT.anchoredPosition = new Vector2(0f, y);
        rowRT.sizeDelta = rowSize;

        // Border
        var border = rowGO.AddComponent<Image>();
        border.color = accent;

        // Inner background
        var bgGO = new GameObject("BG", typeof(RectTransform));
        bgGO.transform.SetParent(rowGO.transform, false);
        var bgRT = bgGO.GetComponent<RectTransform>();
        bgRT.anchorMin = new Vector2(0f, 0f);
        bgRT.anchorMax = new Vector2(1f, 1f);
        bgRT.offsetMin = new Vector2(padding, padding);
        bgRT.offsetMax = new Vector2(-padding, -padding);
        var bg = bgGO.AddComponent<Image>();
        bg.color = new Color(1f, 1f, 1f, 0.92f);

        // Label tinted area
        var labelBGGO = new GameObject("LabelBG", typeof(RectTransform));
        labelBGGO.transform.SetParent(bgGO.transform, false);
        var labelBGRT = labelBGGO.GetComponent<RectTransform>();
        labelBGRT.anchorMin = new Vector2(0f, 0f);
        labelBGRT.anchorMax = new Vector2(0f, 1f);
        labelBGRT.pivot = new Vector2(0f, 0.5f);
        labelBGRT.sizeDelta = new Vector2(labelWidth, 0f);
        labelBGRT.anchoredPosition = Vector2.zero;
        var labelBG = labelBGGO.AddComponent<Image>();
        labelBG.color = new Color(accent.r, accent.g, accent.b, 0.18f);

        // Fill area container (to the right of label)
        var fillAreaGO = new GameObject("FillArea", typeof(RectTransform));
        fillAreaGO.transform.SetParent(bgGO.transform, false);
        var fillAreaRT = fillAreaGO.GetComponent<RectTransform>();
        fillAreaRT.anchorMin = new Vector2(0f, 0f);
        fillAreaRT.anchorMax = new Vector2(1f, 1f);
        fillAreaRT.offsetMin = new Vector2(labelWidth, 0f);
        fillAreaRT.offsetMax = new Vector2(0f, 0f);

        // Fill image (left-anchored, width changes)
        var fillGO = new GameObject("Fill", typeof(RectTransform));
        fillGO.transform.SetParent(fillAreaGO.transform, false);
        var fillRT = fillGO.GetComponent<RectTransform>();
        fillRT.anchorMin = new Vector2(0f, 0f);
        fillRT.anchorMax = new Vector2(0f, 1f);
        fillRT.pivot = new Vector2(0f, 0.5f);
        fillRT.sizeDelta = new Vector2(0f, 0f);
        fillRT.anchoredPosition = Vector2.zero;
        var fill = fillGO.AddComponent<Image>();
        fill.color = new Color(accent.r, accent.g, accent.b, 0.55f);

        // Label text
        var textGO = new GameObject("Label", typeof(RectTransform));
        textGO.transform.SetParent(bgGO.transform, false);
        var textRT = textGO.GetComponent<RectTransform>();
        textRT.anchorMin = new Vector2(0f, 0f);
        textRT.anchorMax = new Vector2(0f, 1f);
        textRT.pivot = new Vector2(0f, 0.5f);
        textRT.sizeDelta = new Vector2(labelWidth, 0f);
        textRT.anchoredPosition = new Vector2(6f, 0f);

        var txt = textGO.AddComponent<Text>();
        txt.text = label;
        txt.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        txt.fontSize = 14;
        txt.color = new Color(0.08f, 0.08f, 0.08f, 1f);
        txt.alignment = TextAnchor.MiddleLeft;

        _fills[label] = fill;

        // Default value so it is visible.
        SetValue(label, 1f);
    }

    /// <summary>
    /// Set a bar value (0..1).
    /// Names are case-insensitive and must match the created labels.
    /// </summary>
    public void SetValue(string statName, float normalizedValue)
    {
        if (string.IsNullOrWhiteSpace(statName)) return;
        if (!_fills.TryGetValue(statName, out var fill) || fill == null) return;

        normalizedValue = Mathf.Clamp01(normalizedValue);
        var rt = fill.rectTransform;

        // FillArea width is the parent rect width.
        float parentWidth = ((RectTransform)rt.parent).rect.width;
        rt.sizeDelta = new Vector2(parentWidth * normalizedValue, 0f);
    }
}
